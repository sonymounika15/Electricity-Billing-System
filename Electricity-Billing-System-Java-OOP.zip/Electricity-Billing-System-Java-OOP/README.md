# Electricity Billing System

## About the Project

This project is a Java-based Electricity Billing System developed using Object-Oriented Programming concepts.

The system is used to add customer details, enter electricity units and rate per unit, calculate the total bill, and search for customer billing details. It provides a simple Graphical User Interface (GUI) using Java Swing.

The main purpose of this project is to reduce manual work and make the electricity billing process faster and easier.

## Features

- Add customer details
- Store customer account number
- Enter units consumed
- Enter rate per unit
- Calculate total electricity bill
- Search customer billing details
- Display generated bill
- Simple GUI
- Input validation
- Uses HashMap for storing billing information

## Technologies Used

- Java
- Java Swing
- AWT
- Object-Oriented Programming
- HashMap

## Requirements

- Java JDK 8 or above
- NetBeans / Eclipse / IntelliJ IDEA
- Windows or Linux

## How to Run

Compile the program:

```bash
javac SimpleEBS.java
```

Run the program:

```bash
java SimpleEBS
```

The Electricity Billing System GUI will open.

## How It Works

The user enters the customer name, account number, units consumed and rate per unit.

The system calculates the bill using:

Total Bill = Units Consumed × Rate per Unit

The customer billing information is stored using a HashMap, where the account number is used to search and retrieve the bill.

## Main Classes

### Customer
Stores customer name and account number.

### ElectricityBill
Stores customer details, units consumed, rate per unit and calculates the total bill.

### SimpleEBS
The main GUI class. It provides options for adding and searching electricity bills.

## Future Improvements

- Connect the system with MySQL
- Store customer records permanently
- Add online payment
- Add automatic tariff updates
- Create a web version
- Create a mobile application
- Add electricity usage tracking
- Add energy-saving suggestions

## Project Information

**Project Title:** Electricity Billing System

**Language:** Java

**Type:** Object-Oriented Programming Project

**GUI:** Java Swing

**Data Storage:** HashMap

**Course:** Object Oriented Programming Laboratory
