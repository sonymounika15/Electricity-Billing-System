import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;

class Customer {
    String name, account;

    Customer(String name, String account) {
        this.name = name;
        this.account = account;
    }
}

class ElectricityBill {
    Customer customer;
    double units, rate;

    ElectricityBill(Customer c, double units, double rate) {
        this.customer = c;
        this.units = units;
        this.rate = rate;
    }

    double total() {
        return units * rate;
    }

    String getDetails() {
        return "----- Electricity Bill -----\n"
                + "Name: " + customer.name + "\n"
                + "Account No: " + customer.account + "\n"
                + "Units: " + units + "\n"
                + "Rate: ₹" + rate + "\n"
                + "----------------------------\n"
                + "Total Bill: ₹" + String.format("%.2f", total()) + "\n";
    }
}

public class SimpleEBS extends JFrame implements ActionListener {

    JTextField nameF, accF, unitF, rateF, searchF;
    JTextArea output;

    HashMap<String, ElectricityBill> data = new HashMap<>();

    SimpleEBS() {
        setTitle("Electricity Billing System");
        setSize(450, 500);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(6, 2, 8, 8));

        panel.add(new JLabel("Name:"));
        nameF = new JTextField();
        panel.add(nameF);

        panel.add(new JLabel("Account No:"));
        accF = new JTextField();
        panel.add(accF);

        panel.add(new JLabel("Units Consumed:"));
        unitF = new JTextField();
        panel.add(unitF);

        panel.add(new JLabel("Rate per Unit:"));
        rateF = new JTextField();
        panel.add(rateF);

        JButton addBtn = new JButton("Add Bill");
        JButton searchBtn = new JButton("Search");

        addBtn.addActionListener(this);
        searchBtn.addActionListener(this);

        panel.add(addBtn);
        panel.add(searchBtn);

        panel.add(new JLabel("Search Account:"));
        searchF = new JTextField();
        panel.add(searchF);

        add(panel, BorderLayout.NORTH);

        output = new JTextArea();
        output.setEditable(false);

        add(new JScrollPane(output), BorderLayout.CENTER);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("Add Bill")) {

            String name = nameF.getText().trim();
            String acc = accF.getText().trim();

            try {
                if (name.isEmpty() || acc.isEmpty()) {
                    throw new Exception();
                }

                double units = Double.parseDouble(unitF.getText());
                double rate = Double.parseDouble(rateF.getText());

                if (units < 0 || rate < 0) {
                    throw new Exception();
                }

                ElectricityBill bill =
                        new ElectricityBill(
                                new Customer(name, acc),
                                units,
                                rate
                        );

                data.put(acc, bill);
                output.setText(bill.getDetails());

                JOptionPane.showMessageDialog(
                        this,
                        "Bill Added Successfully!"
                );

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Enter valid data!"
                );
            }

        } else {

            String acc = searchF.getText().trim();

            ElectricityBill bill = data.get(acc);

            output.setText(
                    bill != null
                            ? bill.getDetails()
                            : "Customer not found!"
            );
        }
    }

    public static void main(String[] args) {
        new SimpleEBS();
    }
}
